## 🛠️ Local Setup for Contributors (Windows)

1. **Clone the Repository**

```bash
git clone https://github.com/stanchat/AIEngagementAcceleratorKit.git
cd AIEngagementAcceleratorKit
```

2. **Run Setup Script**

```bash
setup.bat
```

This will:
- Create and activate a Python virtual environment
- Install dependencies (from `requirements.txt` or defaults)

3. **Launch the App**

```bash
python gradio\gradio_rag_multisource_app.py
```

The Gradio interface will open in your browser at `http://localhost:7860`.

---

> 📌 Make sure you have Python 3.10+ installed and added to your system PATH.
