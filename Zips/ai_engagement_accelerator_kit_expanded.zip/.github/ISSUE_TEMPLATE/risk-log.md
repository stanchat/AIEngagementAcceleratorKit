# Risk Log Entry

- Risk:
- Impact:
- Likelihood:
- Mitigation Plan:
