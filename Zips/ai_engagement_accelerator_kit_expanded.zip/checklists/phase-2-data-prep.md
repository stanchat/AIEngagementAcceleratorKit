# Phase 2 Data Preparation Checklist

- [ ] Data cleaned
- [ ] Models shortlisted
- [ ] Environment configured